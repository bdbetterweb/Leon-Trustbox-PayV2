<?php

namespace Config;

use Admin\Filters\Admin_auth;
use App\Filters\Auth;
use App\Filters\IPBlocker;
use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Filters\CSRF;
use CodeIgniter\Filters\DebugToolbar;
use CodeIgniter\Filters\Honeypot;
use CodeIgniter\Filters\InvalidChars;
use CodeIgniter\Filters\SecureHeaders;
use User\Filters\User_auth;

// Check if the JsonWeb filter file exists
if (!file_exists(APPPATH . 'Filters/JsonWeb.php')) {
    die("Snap! You edited the file.");
}

use App\Filters\JsonWeb; // Import the JsonWeb filter (renamed from LicenseFilter)

class Filters extends BaseConfig
{
    /**
     * Configures aliases for Filter classes to
     * make reading things nicer and simpler.
     */
    public array $aliases = [
        'csrf'          => CSRF::class,
        'toolbar'       => DebugToolbar::class,
        'honeypot'      => Honeypot::class,
        'invalidchars'  => InvalidChars::class,
        'secureheaders' => SecureHeaders::class,
        'auth'          => Auth::class,
        'ipblocker'     => IPBlocker::class,
        'user_auth'     => User_auth::class,
        'admin_auth'    => Admin_auth::class,
        'json_web'      => JsonWeb::class, // Register JsonWeb filter (renamed from LicenseFilter)
    ];

    /**
     * List of filter aliases that are always
     * applied before and after every request.
     */
    public array $globals = [
        'before' => [
            'honeypot',
            'csrf' => ['except' => ['user/add_funds/complete/*', 'api/*', 'invoice/*', 'get_total_notifiaction_count', 'get_user_notifications']],
            'json_web' => ['except' => ['validate-license']], // Exclude the license validation route
        ],
        'after' => [
            'toolbar',
            'honeypot',
            // 'secureheaders',
        ],
    ];

    /**
     * List of filter aliases that works on a
     * particular HTTP method (GET, POST, etc.).
     */
    public array $methods = [];

    /**
     * List of filter aliases that should run on any
     * before or after URI patterns.
     */
    public array $filters = [];
}
