<?php

namespace Config;

class Site_config extends \CodeIgniter\Config\BaseConfig
{
	public $site_title = 'Payment Koro';
	public $site_keywords = 'Payment Automation, Payment Gateway, Payment Koro,uddokta,nagad uddokta,setup uddoktapay pay gateway,nagad uddokta account,uddoktar khoje/ উদ্যোক্তার খোঁজে,uddoktapay,amar pay,uddoktapay java,uddoktapay setup,uddoktapay pricing,uddoktapay apk setup,uddoktapay smm panel,uddoktapay tutorial,smm panel uddoktapay,uddoktapay wordpress,free sms in uddoktapay,uddoktapay setup video,how to setup uddoktapay,uddoktapay notification,uddoktapay installation,nagad bill pay free,uddoktapay android studio,unique pay bd,uique pay,uniquepay bd,bd payment gateway,unique creations ltd,bd payment,uniquepaybd,web bd,uniquepaybd.com tutorial,uniquepaybd.com payment gateway,online income app bd payment bkash 2023,2022 trusted online income app in bd payment bkash,2023 trusted online income app in bd payment bkash,3 bd houses in lancaster pa 17602,physique,3 bd homes for sale in lancaster pa 17602,3 bd houses for sale, payment Koro,payment Koro,pay koro,Koro payment,paymentkoro';
	public $site_description = 'Payment Koro | Automation With Personal Account';
	public $optimize = '0';
	public $site_logo = 'public/uploads/admin/356a192b7913b04c54574d18c28d46e6395428ab/1744362339_cc12ae26ce3d11e97ebe.jpg';
	public $site_icon = 'public/uploads/admin/356a192b7913b04c54574d18c28d46e6395428ab/1744362336_b55edc6ee8175873c8ca.jpg';
	public $site_name = 'PAYMENT KORO';
	public $update_file = '1';
	public $is_maintenance_mode = '0';
	public $maintenance_mode_time = '2024-06-02T20:31';
	public $enable_https = '1';
	public $address = 'Rajshahi,Bangladesh';
	public $social_facebook_link = '';
	public $social_instagram_link = '';
	public $social_pinterest_link = '';
	public $social_twitter_link = '';
	public $social_tumblr_link = '';
	public $social_youtube_link = '';
	public $contact_tel = '+8801305412688';
	public $contact_email = 'support@paymentkoro.com';
	public $contact_work_hour = 'Sat-Thu 09 am - 11 pm';
	public $copy_right_content = 'Copyright © Payment Koro';
	public $honeypot = '';
	public $app_link = '';
	public $payment_url = '';
	public $verify_url = '';
	public $social_fecebook_link = '';
	public $social_github_link = '';
	public $work_hour = '';
	public $contacr_work_hour = '';
	public $google_login = '0';
	public $google_auth_clientId = '997495010105-diioab62jss5taeb6vjbpksvtrs9gs2j.apps.googleusercontent.com';
	public $google_auth_clientSecret = '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';
	public $enable_goolge_translator = '0';
	public $enable_goolge_recapcha = '0';
	public $google_capcha_site_key = '';
	public $google_capcha_secret_key = '';
	public $enable_kyc = '0';
	public $preoloader = '1';
	public $preloader = '0';
	public $enable_google_translator = '1';
	public $enable_google_recapcha = '1';
	public $enable_google_recaptcha = '0';
}
