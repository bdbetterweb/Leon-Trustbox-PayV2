<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class JsonWeb implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Get the license configuration from .env file using env()
        $licenseKey = env('license_key');
        $licenseHost = env('license_host');

        // Check if the license configurations are not set
        if (!$licenseKey || !$licenseHost) {
            return service('response')->setJSON(['status' => false, 'message' => 'License key or host not configured in .env'])->setStatusCode(500);
        }

        // Generate the license URL
        $licenseUrl = $licenseHost . $licenseKey . '.txt';

        // Initialize cURL to fetch the license data
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $licenseUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects if any
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification (optional)

        // Execute the cURL request and get the response
        $licenseData = curl_exec($ch);

        // Check for cURL errors
        if (curl_errno($ch)) {
            return service('response')->setJSON(['status' => false, 'message' => 'cURL Error: ' . curl_error($ch)])->setStatusCode(403);
        }

        curl_close($ch);

        // Check if the license file was fetched
        if (!$licenseData) {
            return service('response')->setJSON(['status' => false, 'message' => 'License file not found'])->setStatusCode(403);
        }

        // Unserialize the license data
        $licenseInfo = @unserialize($licenseData);

        // If license data is not valid
        if (!is_array($licenseInfo)) {
            return service('response')->setJSON(['status' => false, 'message' => 'Invalid license data'])->setStatusCode(403);
        }

        // Extract license information
        $product = $licenseInfo['product'];
        $expirationDate = $licenseInfo['expiration_date'];
        $userWebsite = $licenseInfo['user_website'];
        $generationDate = $licenseInfo['generation_date'];

        // Get the current domain
        $domain = $_SERVER['HTTP_HOST'] ?? 'localhost';

        // Check if the domain matches
        if ($userWebsite !== $domain) {
            return service('response')->setJSON(['status' => false, 'message' => 'Domain mismatch'])->setStatusCode(403);
        }

        // Check if the license has expired
        if (strtotime($expirationDate) < time()) {
            return service('response')->setJSON(['status' => false, 'message' => 'License expired'])->setStatusCode(403);
        }

        // Everything is valid, continue with the request
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // After logic can be implemented if necessary
    }
}
