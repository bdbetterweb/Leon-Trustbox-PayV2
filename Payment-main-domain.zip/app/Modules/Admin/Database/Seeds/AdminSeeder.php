<?php

namespace Admin\Database\Seeds;

use CodeIgniter\Database\Seeder;
use Admin\Models\AdminModel;

class AdminSeeder extends Seeder
{
    public function run()
    {
        $admins = [
            [
                '' => '',
            ]
        ];

        foreach ($admins as $key => $admin) {
            # code...
        }
    }
}
