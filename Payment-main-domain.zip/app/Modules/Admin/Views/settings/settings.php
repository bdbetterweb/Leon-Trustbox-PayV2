<div class="rounded">
  <div class="row settings">
    <div class="col-md-3 col-lg-3">
      <?php include 'sidebar.php'; ?>
    </div>
    <div class="col-md-9 col-lg-9">
      <?php include "elements/$tab.php"; ?>
    </div>
  </div>
</div>

