<section class=" blog-posts m-4" style="padding-top:150px">
    <div class="container">
        <div class="row wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <div id="blog" class="col-xl-12">
                <?= htmlspecialchars_decode(get_option('policy_content'), ENT_QUOTES) ?>
            </div>
        </div>
    </div>
</section>