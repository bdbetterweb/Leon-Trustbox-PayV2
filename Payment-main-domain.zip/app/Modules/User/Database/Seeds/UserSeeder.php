<?php

namespace User\Database\Seeds;

use CodeIgniter\Database\Seeder;
use User\Models\UserModel;

class UserSeeder extends Seeder
{
    public function run()
    {
        $users = [
            [
                '' => '',
            ]
        ];

        foreach ($users as $key => $user) {
            # code...
        }
    }
}
