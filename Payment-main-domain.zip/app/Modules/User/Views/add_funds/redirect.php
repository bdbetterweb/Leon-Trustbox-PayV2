<div class="dimmer active" style="min-height: 400px;">  
<div class="loader"></div>
<div class="dimmer-content">
	<center><h1>Please do not refresh this page...</h1></center>
    <script type="text/javascript">
		window.location.assign("<?php echo $redirect_url; ?>");
	</script>
	</div>
</div>
