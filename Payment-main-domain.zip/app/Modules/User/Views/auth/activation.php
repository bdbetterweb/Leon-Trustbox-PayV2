<div class="card-body">
  
  <p>Please to continue with you account, click the button.</p>
                    <?=form_open('','class="actionForm" data-redirect= "user" ')?>
                    <button type="submit" class="btn btn-success py-3 w-100 mb-4">Activate your Account</button>
                    <?=form_close();?>
</div>

